-- phpMyAdmin SQL Dump
-- version 2.6.3-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 14, 2006 at 03:54 AM
-- Server version: 5.0.12
-- PHP Version: 5.0.5
-- 
-- Database: `njb1_cms_core`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `aliases`
-- 

DROP TABLE IF EXISTS `aliases`;
CREATE TABLE `aliases` (
  `alias` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL
) TYPE=InnoDB;

-- 
-- Dumping data for table `aliases`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `banned`
-- 

DROP TABLE IF EXISTS `banned`;
CREATE TABLE `banned` (
  `reason` varchar(255) NOT NULL,
  `banned` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL
) TYPE=InnoDB;

-- 
-- Dumping data for table `banned`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `clan_types`
-- 

DROP TABLE IF EXISTS `clan_types`;
CREATE TABLE `clan_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `clan_types`
-- 

INSERT INTO `clan_types` VALUES (1, 'Counter-Strike');

-- --------------------------------------------------------

-- 
-- Table structure for table `clans`
-- 

DROP TABLE IF EXISTS `clans`;
CREATE TABLE `clans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
  `expiry_date` date NOT NULL,
  `domain` varchar(255) NOT NULL,
  `disabled` varchar(255) NOT NULL,
  `clan_type` int(11) NOT NULL,
  `account` int(11) NOT NULL,
  `pub_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `clans`
-- 

INSERT INTO `clans` VALUES (1, 'rc', 'Randy Cockers', '2010-01-01', 'rc-clan.com', '', 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `item_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL
) TYPE=InnoDB;

-- 
-- Dumping data for table `comments`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `fixtures`
-- 

DROP TABLE IF EXISTS `fixtures`;
CREATE TABLE `fixtures` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `vs_id` int(10) unsigned NOT NULL,
  `vs_name` varchar(255) NOT NULL,
  `vs_tag` varchar(255) NOT NULL,
  `match_type` int(11) NOT NULL,
  `match_date` datetime NOT NULL,
  `clan_id` int(11) NOT NULL,
  `is_enabled` enum('Y','N') NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `fixtures`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `menus`
-- 

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mod_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `spacer` varchar(255) NOT NULL,
  `custom` varchar(255) NOT NULL,
  `extra` varchar(255) NOT NULL,
  `admin` varchar(255) NOT NULL,
  `userlevel` int(11) NOT NULL,
  `menu_ord` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `menus`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `modules`
-- 

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `actions` varchar(255) NOT NULL,
  `db` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `modules`
-- 

INSERT INTO `modules` VALUES (1, 'home', 'default', '');
INSERT INTO `modules` VALUES (12, 'security', 'default;login;forpass;auth;logout;denied', '');
INSERT INTO `modules` VALUES (13, 'about', 'default', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `news`
-- 

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `edit_note` varchar(255) NOT NULL,
  `create_id` int(11) NOT NULL,
  `edit_id` int(11) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `create_date` datetime NOT NULL,
  `edit_date` datetime NOT NULL,
  `userlevel` varchar(255) NOT NULL,
  `clan_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `news`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `polls_data`
-- 

DROP TABLE IF EXISTS `polls_data`;
CREATE TABLE `polls_data` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userlevel` int(11) NOT NULL,
  `clan_id` int(11) NOT NULL,
  `is_enabled` enum('Y','N') NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `polls_data`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `servers`
-- 

DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(10) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `port` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `clan_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `servers`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `settings_global`
-- 

DROP TABLE IF EXISTS `settings_global`;
CREATE TABLE `settings_global` (
  `clan_id` int(11) NOT NULL
) TYPE=InnoDB;

-- 
-- Dumping data for table `settings_global`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `settings_private`
-- 

DROP TABLE IF EXISTS `settings_private`;
CREATE TABLE `settings_private` (
  `user_id` int(11) NOT NULL
) TYPE=InnoDB;

-- 
-- Dumping data for table `settings_private`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `userlevels`
-- 

DROP TABLE IF EXISTS `userlevels`;
CREATE TABLE `userlevels` (
  `id` int(10) unsigned NOT NULL,
  `info` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `userlevels`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `access` varchar(255) NOT NULL,
  `lastaction` datetime NOT NULL,
  `logged_in` enum('N','Y') NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `clan_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=InnoDB;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'Public', '1;x|2;xxx------|3;xxx-----------|4;xxx------|5;xxx-----------|6;xxx------|7;xxx------xx|8;xxx--------xx|9;xxx-x-x--|10;xxx------|11;-----|12;xxxxxx|13;x|14;xxx|15;-|16;-|17;-|18;----|19;x|20;----------|21;xxx------|', '2006-03-14 03:53:12', 'Y', 0, 1);
